/* ============================================================================
   POC DATA — SINGLE SOURCE OF TRUTH
   ----------------------------------------------------------------------------
   Every tile on the archive page, every entry in the header dropdown, and
   every detail page is generated from this array. To add a new POC:

     1. Add an object below following the same shape.
     2. Give it a unique "id" (used in the URL as poc.html?id=your-id).
     3. Drop your video file path into "src".
     4. (Optional) Drop diagram image paths into diagrams[].image — if left
        blank, the page shows a styled placeholder frame instead.

   Nothing else needs to change — the grid, dropdown, and detail template
   all pick it up automatically.
   ============================================================================ */

const POCS = [
  {
    id: "doc-intelligence",
    index: 1,
    tag: "Document AI",
    title: "Autonomous Document Intelligence",
    tagline: "Turning unstructured paperwork into structured, verifiable decisions.",
    src: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    problem: "Business decision engines are fed by scanned PDFs, DOCX case files, and flow diagrams that were never designed to be machine-readable. Manually reading each document to extract rules, tables, and process flows is slow, error-prone, and doesn't scale as document volume grows.",
    solution: "A three-phase extraction pipeline renders each page, uses a vision-capable LLM to identify structured content (tables, flow nodes, decision paths), and reconciles that output into a single validated schema. Cross-page continuations, ambiguous row boundaries, and format artifacts are resolved automatically before the data ever reaches a downstream system.",
    highlights: [
      "Handles both PDF and DOCX inputs through a unified conversion layer",
      "Resolves cross-page table continuations and row-boundary ambiguity",
      "Outputs structured JSON ready for direct pipeline consumption"
    ],
    diagrams: [
      { caption: "FIG. 01 — EXTRACTION PIPELINE ARCHITECTURE", image: "" },
      { caption: "FIG. 02 — DOCUMENT-TO-SCHEMA DATA FLOW", image: "" }
    ],
    techStack: [
      { category: "Extraction", items: ["PyMuPDF (fitz)", "LibreOffice headless", "Vision LLM"] },
      { category: "Backend", items: ["Python", "FastAPI", "Pydantic"] },
      { category: "Orchestration", items: ["LangChain", "Custom AI Gateway"] },
      { category: "Output", items: ["Structured JSON", "Schema Validation"] }
    ]
  },
  {
    id: "decision-engine",
    index: 2,
    tag: "LLM Systems",
    title: "Conversational Decision Engine",
    tagline: "Ask a business rule engine why it made a decision — in plain language.",
    src: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    problem: "Rule-based decision engines produce outcomes that are difficult for non-technical stakeholders to interpret or challenge. Understanding why a case was approved, flagged, or rejected typically means digging through raw rule configurations or engineering logs.",
    solution: "A natural-language interface sits in front of the decision engine, translating plain-English questions into targeted rule and trace lookups. The model retrieves the exact path a case took through the engine and explains it back in accessible terms, with the original rule reference attached for auditability.",
    highlights: [
      "Explains rule-engine outcomes in plain language with source traceability",
      "Retrieves the exact decision path a case followed, not a generic summary",
      "Built for non-technical stakeholders to self-serve without engineering support"
    ],
    diagrams: [
      { caption: "FIG. 01 — QUERY-TO-EXPLANATION FLOW", image: "" },
      { caption: "FIG. 02 — DECISION TRACE RETRIEVAL MODEL", image: "" }
    ],
    techStack: [
      { category: "AI / ML", items: ["LLM Reasoning Layer", "Prompt Orchestration"] },
      { category: "Backend", items: ["Python", "FastAPI"] },
      { category: "Integration", items: ["Decision Engine API", "Okta Auth"] },
      { category: "Interface", items: ["Chat-style Query UI"] }
    ]
  },
  {
    id: "robotic-sorter",
    index: 3,
    tag: "Robotics",
    title: "Vision-Guided Robotic Sorter",
    tagline: "Real-time perception and manipulation for high-mix sorting tasks.",
    src: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
    problem: "Warehouse sorting lines handling mixed, irregularly placed items are hard to automate with fixed-position tooling. Objects vary in shape, orientation, and lighting condition, which breaks traditional rule-based vision systems.",
    solution: "A real-time object detection model identifies and localizes items on the belt, streaming coordinates to a robotic arm controller that adjusts grip and placement on the fly. The system re-calibrates continuously against a moving belt reference frame rather than relying on static calibration.",
    highlights: [
      "Real-time detection and localization under variable lighting",
      "Dynamic grip and placement adjustment on a moving reference frame",
      "Designed for high item-mix environments, not a fixed SKU set"
    ],
    diagrams: [
      { caption: "FIG. 01 — PERCEPTION-TO-ACTUATION PIPELINE", image: "" },
      { caption: "FIG. 02 — SORTING CELL LAYOUT", image: "" }
    ],
    techStack: [
      { category: "Vision", items: ["Object Detection Model", "Camera Calibration"] },
      { category: "Control", items: ["Robotic Arm Controller", "Motion Planning"] },
      { category: "Backend", items: ["Python", "ROS"] },
      { category: "Infra", items: ["Edge Inference"] }
    ]
  },
  {
    id: "fraud-detection",
    index: 4,
    tag: "Applied ML",
    title: "Fraud Signal Detection",
    tagline: "Scoring transaction risk in real time, with a reason attached.",
    src: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
    problem: "Fraud teams need to catch anomalous transactions as they happen, not after settlement — but black-box risk scores are hard to act on or defend during review. A model that flags a transaction without explaining why creates as much work as it saves.",
    solution: "A gradient-boosted model scores each transaction against behavioral and velocity features in real time, and every score is paired with a feature-attribution breakdown so analysts can see exactly which signals drove the decision. Flagged cases route automatically into a review queue with the explanation attached.",
    highlights: [
      "Real-time scoring on live transaction streams",
      "Explainable output via feature attribution, not a bare risk number",
      "Automatic routing of flagged cases into an analyst review queue"
    ],
    diagrams: [
      { caption: "FIG. 01 — STREAMING SCORING ARCHITECTURE", image: "" },
      { caption: "FIG. 02 — EXPLAINABILITY & REVIEW ROUTING", image: "" }
    ],
    techStack: [
      { category: "AI / ML", items: ["XGBoost / LightGBM", "SHAP"] },
      { category: "Streaming", items: ["Kafka", "Redis"] },
      { category: "Backend", items: ["FastAPI", "Python"] },
      { category: "Data", items: ["Feature Store"] }
    ]
  },
  {
    id: "agent-orchestration",
    index: 5,
    tag: "Agentic AI",
    title: "Multi-Agent Task Orchestration",
    tagline: "Several specialized agents, one coordinated operational workflow.",
    src: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
    problem: "Complex operational workflows often span multiple systems and decision types that no single model handles well end to end. Hand-coding the coordination logic between specialized tools is brittle and hard to extend as new steps get added.",
    solution: "A planning agent decomposes an incoming task into subtasks and delegates each to a specialized worker agent — retrieval, computation, or action — then reconciles their outputs into a single completed workflow. Each agent's reasoning and tool calls are logged for full traceability.",
    highlights: [
      "Planning agent decomposes tasks and delegates to specialized workers",
      "Reconciles multi-agent outputs into one coherent result",
      "Full reasoning and tool-call trace for every workflow run"
    ],
    diagrams: [
      { caption: "FIG. 01 — AGENT ORCHESTRATION TOPOLOGY", image: "" },
      { caption: "FIG. 02 — TASK DELEGATION & RECONCILIATION FLOW", image: "" }
    ],
    techStack: [
      { category: "Orchestration", items: ["LangChain", "Custom Planner Agent"] },
      { category: "Backend", items: ["Python", "FastAPI"] },
      { category: "Observability", items: ["Structured Logging", "Trace Store"] },
      { category: "Integration", items: ["Internal Tool APIs"] }
    ]
  }
];

// expose for plain <script> usage across pages
window.POCS = POCS;
