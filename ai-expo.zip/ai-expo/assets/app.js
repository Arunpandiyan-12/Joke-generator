/* ============================================================================
   SHARED APP LOGIC
   Used by both index.html and poc.html. Relies on window.POCS from data.js.
   ============================================================================ */

function pad(n){ return String(n).padStart(2, '0'); }

/* ---------------- live clock ---------------- */
function initClock(){
  const el = document.getElementById('clock');
  if (!el) return;
  function tick(){
    const d = new Date();
    el.textContent = `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  }
  tick();
  setInterval(tick, 1000);
}

/* ---------------- header dropdown ---------------- */
function initPocMenu(){
  const menu = document.getElementById('pocMenu');
  const btn = document.getElementById('pocMenuBtn');
  const list = document.getElementById('pocMenuList');
  if (!menu || !btn || !list) return;

  list.innerHTML = POCS.map(p => `
    <li>
      <a class="poc-menu-item" href="poc.html?id=${p.id}">
        <span class="poc-menu-idx">TX-${pad(p.index)}</span>
        <span class="poc-menu-item-text">
          <span class="poc-menu-item-title">${p.title}</span>
          <span class="poc-menu-item-tag">${p.tag}</span>
        </span>
      </a>
    </li>
  `).join('');

  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    menu.classList.toggle('open');
  });
  document.addEventListener('click', (e) => {
    if (!menu.contains(e.target)) menu.classList.remove('open');
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') menu.classList.remove('open');
  });
}

/* ---------------- fullscreen video modal ---------------- */
let lastFocused = null;

function openPlayer(pocOrIndex){
  const p = typeof pocOrIndex === 'number' ? POCS[pocOrIndex] : pocOrIndex;
  const modal = document.getElementById('modal');
  const video = document.getElementById('playerVideo');
  const modalTitle = document.getElementById('modalTitle');
  const closeBtn = document.getElementById('closeBtn');
  if (!modal || !video) return;

  lastFocused = document.activeElement;
  modalTitle.textContent = `TX-${pad(p.index)} — ${p.title}`;
  video.src = p.src;
  modal.classList.add('open');
  document.body.style.overflow = 'hidden';
  video.play().catch(() => {});
  if (closeBtn) closeBtn.focus();

  requestAnimationFrame(() => {
    const frame = document.querySelector('.modal-frame');
    const target = frame.requestFullscreen ? frame : video;
    if (target.requestFullscreen) target.requestFullscreen().catch(() => {});
  });
}

function closePlayer(){
  const modal = document.getElementById('modal');
  const video = document.getElementById('playerVideo');
  if (!modal || !video) return;
  if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
  modal.classList.remove('open');
  document.body.style.overflow = '';
  video.pause();
  video.removeAttribute('src');
  video.load();
  if (lastFocused) lastFocused.focus();
}

function initModal(){
  const modal = document.getElementById('modal');
  const closeBtn = document.getElementById('closeBtn');
  const fsBtn = document.getElementById('fsBtn');
  if (!modal) return;

  if (closeBtn) closeBtn.addEventListener('click', closePlayer);
  if (fsBtn){
    fsBtn.addEventListener('click', () => {
      const frame = document.querySelector('.modal-frame');
      const video = document.getElementById('playerVideo');
      if (!document.fullscreenElement){
        (frame.requestFullscreen ? frame : video).requestFullscreen().catch(() => {});
      } else {
        document.exitFullscreen().catch(() => {});
      }
    });
  }
  modal.addEventListener('click', (e) => { if (e.target === modal) closePlayer(); });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal.classList.contains('open')) closePlayer();
  });
}

/* ---------------- scroll reveal ---------------- */
function initScrollReveal(){
  const targets = document.querySelectorAll('.reveal, .reveal-stagger');
  if (!targets.length) return;
  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting){
        entry.target.classList.add('in-view');
        io.unobserve(entry.target);
      }
    });
  }, { threshold: 0.16, rootMargin: '0px 0px -40px 0px' });
  targets.forEach(t => io.observe(t));
}

/* ---------------- top scroll-progress rail ---------------- */
function initProgressBar(){
  const fill = document.getElementById('progressFill');
  if (!fill) return;
  function update(){
    const h = document.documentElement;
    const scrolled = h.scrollTop;
    const max = h.scrollHeight - h.clientHeight;
    fill.style.width = max > 0 ? `${(scrolled / max) * 100}%` : '0%';
  }
  update();
  document.addEventListener('scroll', update, { passive: true });
  window.addEventListener('resize', update);
}

/* ---------------- side section-dot nav (detail pages) ---------------- */
function initSectionNav(){
  const nav = document.getElementById('sectionNav');
  const sections = document.querySelectorAll('.detail-section');
  if (!nav || !sections.length) return;

  nav.innerHTML = Array.from(sections).map((s, i) =>
    `<button data-target="${s.id}" aria-label="Jump to ${s.dataset.label || 'section'}" ${i === 0 ? 'class="active"' : ''}></button>`
  ).join('');

  const dots = nav.querySelectorAll('button');
  dots.forEach(dot => {
    dot.addEventListener('click', () => {
      document.getElementById(dot.dataset.target).scrollIntoView({ behavior: 'smooth' });
    });
  });

  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting){
        dots.forEach(d => d.classList.toggle('active', d.dataset.target === entry.target.id));
      }
    });
  }, { threshold: 0.5 });
  sections.forEach(s => io.observe(s));
}
