/* ============================================================================
   DETAIL PAGE RENDERER
   Reads ?id= from the URL, looks it up in POCS (data.js), and builds the page.
   ============================================================================ */

(function(){
  const params = new URLSearchParams(window.location.search);
  const id = params.get('id');
  const poc = POCS.find(p => p.id === id) || POCS[0];
  const i = POCS.indexOf(poc);
  const prev = POCS[(i - 1 + POCS.length) % POCS.length];
  const next = POCS[(i + 1) % POCS.length];

  document.title = `${poc.title} — AI EXPO`;
  document.getElementById('crumbCurrent').textContent = `TX-${pad(poc.index)} — ${poc.title}`;

  const watchIcon = `<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>`;
  const diagramIcon = `<svg viewBox="0 0 48 48"><rect x="6" y="8" width="14" height="10" rx="1"/><rect x="28" y="8" width="14" height="10" rx="1"/><rect x="17" y="30" width="14" height="10" rx="1"/><path d="M13 18v6h22v-6M24 24v6" fill="none"/></svg>`;

  function diagramBlock(d){
    if (d.image){
      return `
        <div class="diagram-frame reveal">
          <img src="${d.image}" alt="${d.caption}">
        </div>
        <div class="diagram-caption">${d.caption}</div>
      `;
    }
    return `
      <div>
        <div class="diagram-frame reveal">
          <div class="diagram-placeholder">
            ${diagramIcon}
            <span>Diagram space<br>ready for upload</span>
          </div>
        </div>
        <div class="diagram-caption">${d.caption}</div>
      </div>
    `;
  }

  document.getElementById('pageBody').innerHTML = `
    <section class="detail-hero">
      <div class="detail-hero-top">
        <span class="detail-index">TX-${pad(poc.index)}</span>
        <span class="detail-tag">${poc.tag}</span>
      </div>
      <h1>${poc.title}</h1>
      <p class="detail-tagline">${poc.tagline}</p>
      <button class="watch-btn" id="watchDemoBtn">${watchIcon} Watch full demo</button>
    </section>

    <section class="detail-section" id="sec-problem" data-label="Problem Statement">
      <div class="section-label"><span class="num">01</span> Problem Statement</div>
      <h2 class="section-title reveal">What we were up against</h2>
      <p class="section-body reveal">${poc.problem}</p>
    </section>

    <section class="detail-section" id="sec-solution" data-label="Solution">
      <div class="section-label"><span class="num">02</span> Solution</div>
      <h2 class="section-title reveal">How it works</h2>
      <p class="section-body reveal">${poc.solution}</p>
      <div class="highlight-list reveal-stagger">
        ${poc.highlights.map(h => `
          <div class="highlight-item"><span class="dot"></span><p>${h}</p></div>
        `).join('')}
      </div>
    </section>

    <section class="detail-section" id="sec-architecture" data-label="System Overview">
      <div class="section-label"><span class="num">03</span> System Overview</div>
      <h2 class="section-title reveal">Architecture &amp; data flow</h2>
      <div class="diagram-grid">
        ${poc.diagrams.map(diagramBlock).join('')}
      </div>
    </section>

    <section class="detail-section" id="sec-stack" data-label="Tech Stack">
      <div class="section-label"><span class="num">04</span> Tech Stack</div>
      <h2 class="section-title reveal">What it's built with</h2>
      <div class="stack-grid reveal-stagger">
        ${poc.techStack.map(g => `
          <div class="stack-group">
            <div class="stack-group-name">${g.category}</div>
            <div class="stack-chips">
              ${g.items.map(item => `<span class="chip">${item}</span>`).join('')}
            </div>
          </div>
        `).join('')}
      </div>
    </section>
  `;

  document.getElementById('detailNav').innerHTML = `
    <a class="detail-nav-link prev" href="poc.html?id=${prev.id}">
      <span class="detail-nav-label">← Previous transmission</span>
      <span class="detail-nav-title">TX-${pad(prev.index)} — ${prev.title}</span>
    </a>
    <a class="detail-nav-link next" href="poc.html?id=${next.id}">
      <span class="detail-nav-label">Next transmission →</span>
      <span class="detail-nav-title">TX-${pad(next.index)} — ${next.title}</span>
    </a>
  `;

  document.getElementById('watchDemoBtn').addEventListener('click', () => openPlayer(poc));

  initPocMenu();
  initModal();
  initClock();
  initProgressBar();
  initSectionNav();
  initScrollReveal();
})();
